module ULC where

import Data.List

data Var = A | B | C | D | E | F | G | H | I | J | K | L | M | N | O | P | Q | R | S | U | V | W | X | Y | Z deriving (Show, Eq)
data T = Variable Var | Lambda Var T | Term T T deriving (Show, Eq)

listOfAllVar = [A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, U, V, W, X, Y, Z]
listOfAllVarWithVariable = [Variable A, Variable B, Variable C, Variable D, Variable E, Variable F, Variable G, Variable H, Variable I, Variable J, Variable K, Variable L, Variable M, Variable N, Variable O, Variable P, Variable Q, Variable R, Variable S, Variable U, Variable V, Variable W, Variable X, Variable Y, Variable Z]

fv :: T -> [Var]

fv (Variable x) = [x]
fv (Lambda x t1) = (fv(t1) \\ [x])
fv (Term t1 t2) = ((fv t1) `union` (fv t2))

listOfVar :: T -> [Var]
listOfVar (Variable x) = [x]
listOfVar (Lambda x y) = [x] `union` (listOfVar y)
listOfVar (Term x y) = ((listOfVar x) `union` (listOfVar y))

relabel :: T -> Var -> Var -> T

relabel (Variable x) y z
    | x == y    = (Variable z)
    | otherwise = (Variable x)
relabel (Lambda x t1) y z
    | x == y    = (Lambda z (relabel t1 y z))
    | otherwise = (Lambda x (relabel t1 y z))
relabel (Term t1 t2) y z = (Term (relabel t1 y z) (relabel t2 y z))

changeVar :: [Var] -> Var
changeVar x = head(listOfAllVar \\ x)

sub :: T -> Var -> T -> T
sub (Variable x) y z
    | x == y    = z
    | otherwise = (Variable x)
 
sub (Lambda x t1) y z
    | (x /= y) && (not(x `elem` (fv z))) = (Lambda x (sub t1 y z))
    | x == y || x/=y && (x `elem` (fv z)) = sub (relabel (Lambda x t1) x (head(listOfAllVar \\ (listOfVar (Lambda x t1))))) y z
    | otherwise = (Lambda x t1)

sub (Term t1 t2) y z = Term (sub t1 y z) (sub t2 y z)

isNF :: T -> Bool
isNF (Variable t1) = True
isNF (Lambda x y)
    | isNF(y) = True
    | otherwise = False
isNF (Term t1 t2)
    | t2 `elem` listOfAllVarWithVariable = True
    | otherwise = False

ssos :: T -> T
ssos (Lambda x y)
    | not(isNF y) = Lambda x (ssos y)
    | otherwise = Lambda x y
ssos (Term (Lambda x y) z)
    | isNF z = (sub y x z)
    | otherwise = ssos y
ssos (Term t1 t2)
    | not (isNF t1) = Term (ssos t1) t2
    | isNF t1 && not (isNF t2) = Term t1 (ssos t2)

eval :: T -> T
eval t
    | (ssos(t) == t) = t
    | otherwise = eval(ssos(t))