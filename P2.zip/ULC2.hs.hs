module ULC2 where

import ULC

logicalAnd :: T -> T -> T
logicalAnd t1 t2 = eval(ssos (Term (ssos(Term (Lambda P (Lambda Q (Term (Term (Variable P) (Variable Q)) (Variable P)))) t1)) t2))

logicalOr :: T -> T -> T
logicalOr t1 t2 = eval(ssos (Term (ssos(Term (Lambda P (Lambda Q (Term (Term (Variable P) (Variable P)) (Variable Q)))) t1)) t2))

numericSum :: T -> T -> T
numericSum t1 t2 = eval(ssos(Term (ssos(Term (Lambda M (Lambda N (Lambda S (Lambda Z (Term (Term (Variable M) (Variable S)) (Term (Term (Variable N) (Variable S)) (Variable Z))))))) t1))t2))