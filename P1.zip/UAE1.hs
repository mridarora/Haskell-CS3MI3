module UAE1 where

data UAE = Succ UAE | Pred UAE | IsZero UAE | IfThenElse UAE UAE UAE | NV NumericValue | V Value deriving (Show, Eq)

data NumericValue = Z | SuccVal NumericValue deriving (Show, Eq)

data Value = T | F | Wrong deriving (Show, Eq)
    
ssos :: UAE -> UAE

ssos (Pred(NV(Z))) = (NV(Z))
ssos (IfThenElse (V(T)) t1 t2) = (t1)
ssos (IfThenElse (V(F)) t1 t2) = (t2)
ssos (IfThenElse t1 t2 t3) = (IfThenElse (ssos t1) (ssos t2) (ssos t3))
ssos (Succ(t1)) = (Succ(ssos(t1)))
ssos (Pred(Succ(t))) = (t)
ssos (IsZero(NV(Z))) = (V T)
ssos (IsZero(Succ(NV t))) = (V F)
ssos (Pred(t1)) = (Pred(ssos(t1)))
ssos (IsZero(t1)) = (IsZero(ssos(t1)))
ssos (V T) = (V T)
ssos (V F) = (V F)
ssos (NV Z) = (NV Z)
--ssos (Succ(NV(t))) = (NV(SuccVal(t)))

eval :: UAE -> UAE
eval t
    | (ssos(t) == t) = t
    | otherwise = eval(ssos(t))