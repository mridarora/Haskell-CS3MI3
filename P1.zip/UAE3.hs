module UAE3 where

data UAE = Succ UAE | Pred UAE | IsZero UAE | IfThenElse UAE UAE UAE | NV NumericValue | V Value deriving (Show, Eq)

data NumericValue = Z | SuccVal NumericValue deriving (Show, Eq)

data Value = T | F | Wrong deriving (Show, Eq)
    
bsos :: UAE -> UAE

bsos (IfThenElse (V Wrong) t1 t2) = (V Wrong)
bsos (IfThenElse t1 (V Wrong) t2) = (V Wrong)
bsos (IfThenElse t1 t2 (V Wrong)) = (V Wrong)
bsos (IfThenElse (NV t) t1 t2) = (V Wrong)
bsos (Succ(V T)) = (V Wrong)
bsos (Succ(V Wrong)) = (V Wrong)
bsos (Succ(V F)) = (V Wrong)
bsos (Pred(V T)) = (V Wrong)
bsos (Pred(V Wrong)) = (V Wrong)
bsos (Pred(V F)) = (V Wrong)
bsos (IsZero(V Wrong)) = (V Wrong)
bsos (IsZero(V T)) = (V Wrong)
bsos (IsZero(V F)) = (V Wrong)
bsos (Pred(NV(Z))) = (NV(Z))
bsos (IfThenElse (V(T)) t1 t2) = (t1)
bsos (IfThenElse (V(F)) t1 t2) = (t2)
bsos (IfThenElse t1 t2 t3) = (IfThenElse (bsos t1) (bsos t2) (bsos t3))
bsos (Succ(t1)) = (Succ(bsos(t1)))
bsos (Pred(Succ(t))) = (t)
bsos (IsZero(NV(Z))) = (V T)
bsos (IsZero(Succ(NV t))) = (V F)
bsos (Pred(t1)) = (Pred(bsos(t1)))
bsos (IsZero(t1)) = (IsZero(bsos(t1)))
bsos (V T) = (V T)
bsos (V F) = (V F)
bsos (NV Z) = (NV Z)
bsos (V Wrong) = (V Wrong)