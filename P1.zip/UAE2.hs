module UAE2 where

data UAE = Succ UAE | Pred UAE | IsZero UAE | IfThenElse UAE UAE UAE | NV NumericValue | V Value deriving (Show, Eq)

data NumericValue = Z | SuccVal NumericValue deriving (Show, Eq)

data Value = T | F | Wrong deriving (Show, Eq)
    
ssos :: UAE -> UAE

ssos (IfThenElse (V Wrong) t1 t2) = (V Wrong)
ssos (IfThenElse t1 (V Wrong) t2) = (V Wrong)
ssos (IfThenElse t1 t2 (V Wrong)) = (V Wrong)
ssos (IfThenElse (NV t) t1 t2) = (V Wrong)
ssos (Succ(V T)) = (V Wrong)
ssos (Succ(V Wrong)) = (V Wrong)
ssos (Succ(V F)) = (V Wrong)
ssos (Pred(V T)) = (V Wrong)
ssos (Pred(V Wrong)) = (V Wrong)
ssos (Pred(V F)) = (V Wrong)
ssos (IsZero(V Wrong)) = (V Wrong)
ssos (IsZero(V T)) = (V Wrong)
ssos (IsZero(V F)) = (V Wrong)
ssos (Pred(NV(Z))) = (NV(Z))
ssos (IfThenElse (V(T)) t1 t2) = (t1)
ssos (IfThenElse (V(F)) t1 t2) = (t2)
ssos (IfThenElse t1 t2 t3) = (IfThenElse (ssos t1) (ssos t2) (ssos t3))
ssos (Succ(t1)) = (Succ(ssos(t1)))
ssos (Pred(Succ(t))) = (t)
ssos (IsZero(NV(Z))) = (V T)
ssos (IsZero(Succ(NV t))) = (V F)
ssos (Pred(t1)) = (Pred(ssos(t1)))
ssos (IsZero(t1)) = (IsZero(ssos(t1)))
ssos (V T) = (V T)
ssos (V F) = (V F)
ssos (NV Z) = (NV Z)
ssos (V Wrong) = (V Wrong)

--ssos (Succ(NV(t))) = (NV(SuccVal(t)))

eval :: UAE -> UAE
eval t
    | (ssos(t) == (V Wrong)) = (V Wrong)
    | (ssos(t) == t) = t
    | otherwise = eval(ssos(t))